# RegulOS — Imagem obrigatória antes de salvar

## Alteração
- O endpoint de criação de agendamento agora valida a imagem antes de persistir o agendamento.
- O endpoint de edição aplica a mesma validação antes de salvar alterações.
- A busca automática tenta, nesta ordem, fontes de metadados/API e um navegador headless para páginas que carregam imagens via JavaScript.
- Se nenhuma imagem válida puder ser obtida, o agendamento/edição é recusado e não é salvo.
- O envio continua com uma segunda proteção: sem imagem válida, não envia somente texto e registra a falha.
- Quando uma imagem é validada, sua URL é armazenada no agendamento para reutilização no envio.

## Validação técnica
- `node --check src/server.js` passou sem erros.

## Observação
A regra garante o comportamento do RegulOS: não salvar/enviar uma oferta sem imagem válida. Isso não significa que toda página externa obrigatoriamente disponibilize uma imagem acessível; nesses casos o sistema recusa o agendamento em vez de enviar sem imagem.
