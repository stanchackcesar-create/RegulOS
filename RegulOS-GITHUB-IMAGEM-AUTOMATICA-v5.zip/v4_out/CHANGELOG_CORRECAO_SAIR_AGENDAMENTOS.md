# Correção — agendamento uma vez sai após envio

- Agendamentos `uma_vez` concluídos agora são removidos imediatamente de `link_agendamentos.json`.
- O registro concluído permanece no Histórico.
- Registros antigos que ficaram como `concluido` na lista de Agendamentos são migrados automaticamente para o Histórico na inicialização.
- A API de Agendamentos também não exibe registros `uma_vez` já concluídos, como proteção adicional contra cache/estado antigo.
- Agendamentos recorrentes continuam na lista normalmente.
- A regra de busca automática de imagem foi preservada.
